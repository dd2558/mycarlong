package com.mycarlong.mycarlongback;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MycarlongBackApplicationTests {

	@Test
	void contextLoads() {
	}

}
